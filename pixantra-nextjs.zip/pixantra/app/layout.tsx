import type { Metadata } from "next";
import "./globals.css";
import Nav from "@/components/Nav";
import Cursor from "@/components/Cursor";
import ScrollProgress from "@/components/ScrollProgress";

export const metadata: Metadata = {
  title: "Pixantra — Digital Marketing Agency",
  description:
    "Performance-driven digital marketing agency helping ambitious brands achieve extraordinary growth.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <Cursor />
        <ScrollProgress />
        <Nav />
        {children}
      </body>
    </html>
  );
}
