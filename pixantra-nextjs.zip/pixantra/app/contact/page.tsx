"use client";

import { useState } from "react";
import Footer from "@/components/Footer";

const faqs = [
  { q: "How long until we see results?", a: "SEO takes 3-6 months for significant results. Paid media can show results within weeks. We'll set clear milestones from day one." },
  { q: "Do you require long-term contracts?", a: "We offer month-to-month agreements. We believe our results speak for themselves — we've never needed to lock clients in." },
  { q: "Who will be working on my account?", a: "Senior specialists lead every account. You'll have a dedicated account manager as your single point of contact throughout." },
  { q: "What industries do you specialize in?", a: "SaaS, e-commerce, B2B, finance, education, and professional services. We work across industries with equal success." },
];

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  return (
    <>
      {/* Hero */}
      <div className="page-hero-accent relative overflow-hidden bg-[#f7f5f0] px-10 pb-24 pt-40">
        <div className="relative mx-auto max-w-[1200px]">
          <div className="mb-6 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            Let's Talk
          </div>
          <h1 className="max-w-[800px] font-syne text-[clamp(2.5rem,5vw,4.5rem)] font-extrabold leading-[1.05] tracking-[-1.5px] text-[#1a1a1a]">
            Ready to Grow? Let's<br />Start a Conversation
          </h1>
          <p className="mt-6 max-w-[520px] text-[1.05rem] leading-[1.75] text-[#666]">
            Whether you have a specific project in mind or just want to explore what's possible, we'd love to hear from you.
          </p>
        </div>
      </div>

      {/* Grid */}
      <div className="mx-auto max-w-[1200px] px-10 py-24">
        <div className="grid grid-cols-1 items-start gap-20 md:grid-cols-[1fr_1.3fr]">
          {/* Info */}
          <div className="flex flex-col gap-8">
            <div>
              <div className="mb-5 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
                <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
                Get in Touch
              </div>
              <h2 className="mb-4 font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
                We're Here to<br />Answer Every Question
              </h2>
              <p className="text-[1rem] leading-[1.75] text-[#666]">
                Drop us a line or schedule a call. We respond to every inquiry within 24 hours — usually much sooner.
              </p>
            </div>

            {[
              { icon: "✉️", label: "Email Us", val: "hello@pixantra.com" },
              { icon: "📞", label: "Call Us", val: "+1 (555) 234-5678" },
              { icon: "📍", label: "Office", val: "250 Park Avenue, New York, NY 10017" },
              { icon: "🕐", label: "Hours", val: "Mon–Fri: 9am–6pm EST" },
            ].map((d, i) => (
              <div key={i} className="flex items-start gap-5">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-[12px] border border-[#0f78ed]/20 bg-[#0f78ed]/10 text-[1.2rem] text-[#0f78ed]">
                  {d.icon}
                </div>
                <div>
                  <div className="mb-1.5 text-[0.78rem] font-semibold uppercase tracking-[1.5px] text-[#666]">{d.label}</div>
                  <div className="text-[0.95rem] font-semibold text-[#1a1a1a]">{d.val}</div>
                </div>
              </div>
            ))}

            <div className="rounded-[22px] bg-[#111] p-8">
              <div className="mb-3 font-syne text-[1rem] font-bold text-white">Free Strategy Session</div>
              <div className="mb-5 text-[0.88rem] leading-[1.7] text-[#888]">
                Book a 30-minute call with a senior strategist. No sales pitch, just genuine advice on how to grow your business.
              </div>
              <button
                className="inline-flex items-center gap-2 rounded-full bg-[#0f78ed] px-6 py-3 text-[0.88rem] font-bold text-white transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#3d96f5]"
                style={{ cursor: "none" }}
                onClick={() => document.getElementById("contact-form")?.scrollIntoView({ behavior: "smooth" })}
              >
                Book Now →
              </button>
            </div>
          </div>

          {/* Form */}
          <div
            id="contact-form"
            className="rounded-[32px] border border-[#e8e4dc] bg-white p-12"
          >
            <div className="mb-8">
              <div className="mb-2 font-syne text-[1.3rem] font-extrabold text-[#1a1a1a]">Send Us a Message</div>
              <div className="text-[0.88rem] text-[#666]">Fill out the form below and we'll get back to you within 24 hours.</div>
            </div>

            <div className="grid grid-cols-2 gap-5">
              <div className="col-span-1 flex flex-col gap-2">
                <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">First Name</label>
                <input type="text" placeholder="Alex" className="form-input w-full rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] text-[#1a1a1a] transition-all duration-200" />
              </div>
              <div className="col-span-1 flex flex-col gap-2">
                <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">Last Name</label>
                <input type="text" placeholder="Johnson" className="form-input w-full rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] text-[#1a1a1a] transition-all duration-200" />
              </div>
              <div className="col-span-1 flex flex-col gap-2">
                <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">Email Address</label>
                <input type="email" placeholder="alex@company.com" className="form-input w-full rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] text-[#1a1a1a] transition-all duration-200" />
              </div>
              <div className="col-span-1 flex flex-col gap-2">
                <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">Phone (optional)</label>
                <input type="tel" placeholder="+1 (555) 000-0000" className="form-input w-full rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] text-[#1a1a1a] transition-all duration-200" />
              </div>
            </div>

            <div className="mt-6 flex flex-col gap-2">
              <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">Company Name</label>
              <input type="text" placeholder="Your company" className="form-input w-full rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] text-[#1a1a1a] transition-all duration-200" />
            </div>

            <div className="mt-6 flex flex-col gap-2">
              <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">Service Interested In</label>
              <select className="form-select w-full appearance-none rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] text-[#1a1a1a] transition-all duration-200">
                <option value="" disabled>Select a service...</option>
                {["SEO Marketing", "Paid Advertising", "Content Strategy", "Social Media", "Email Marketing", "Brand Identity", "Full-Service Package"].map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>

            <div className="mt-6 flex flex-col gap-2">
              <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">Monthly Budget</label>
              <select className="form-select w-full appearance-none rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] text-[#1a1a1a] transition-all duration-200">
                <option value="" disabled>Select budget range...</option>
                {["Under $1,000/mo", "$1,000 – $3,000/mo", "$3,000 – $7,000/mo", "$7,000 – $15,000/mo", "$15,000+/mo"].map((b) => (
                  <option key={b}>{b}</option>
                ))}
              </select>
            </div>

            <div className="mt-6 flex flex-col gap-2">
              <label className="text-[0.82rem] font-semibold tracking-[0.3px] text-[#1a1a1a]">Tell Us About Your Project</label>
              <textarea
                rows={5}
                placeholder="What are your goals? What challenges are you facing? The more detail, the better..."
                className="form-textarea w-full resize-y rounded-[10px] border border-[#e8e4dc] bg-[#f7f5f0] px-4 py-3.5 font-dm text-[0.9rem] leading-[1.6] text-[#1a1a1a] transition-all duration-200"
              />
            </div>

            <button
              onClick={handleSubmit}
              disabled={loading || submitted}
              className={`mt-8 w-full rounded-full py-4 font-syne text-[1rem] font-bold tracking-[0.5px] text-white transition-all duration-200 ${
                submitted
                  ? "bg-[#10b981]"
                  : "bg-[#0f78ed] hover:-translate-y-0.5 hover:bg-[#3d96f5] hover:shadow-[0_15px_30px_rgba(15,120,237,0.3)]"
              }`}
              style={{ cursor: "none" }}
            >
              {loading ? "Sending..." : submitted ? "✓ Message Sent! We'll be in touch within 24 hours." : "Send Message →"}
            </button>
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div className="bg-[#111]">
        <div className="mx-auto max-w-[1200px] px-10 py-24">
          <div className="mb-16 text-center">
            <div className="mb-5 inline-flex items-center justify-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
              <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
              FAQ
            </div>
            <h2 className="mx-auto max-w-[700px] font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-white">
              Common Questions<br />We Get Asked
            </h2>
          </div>
          <div className="mx-auto grid max-w-[900px] grid-cols-1 gap-6 md:grid-cols-2">
            {faqs.map((f, i) => (
              <div key={i} className="rounded-[14px] border border-[#2a2a2a] bg-[#1a1a1a] p-8">
                <div className="mb-3 font-syne text-[1rem] font-bold text-white">{f.q}</div>
                <div className="text-[0.87rem] leading-[1.7] text-[#888]">{f.a}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
