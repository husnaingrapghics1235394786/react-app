import Link from "next/link";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const team = [
  { initials: "AK", name: "Alex Kim", role: "CEO & Founder", bio: "10+ years driving growth for Fortune 500s and high-growth startups across tech, retail, and finance." },
  { initials: "SR", name: "Sofia Reyes", role: "Head of Strategy", bio: "Former McKinsey consultant turned digital strategist, specializing in brand positioning and market entry." },
  { initials: "JL", name: "James Lee", role: "Creative Director", bio: "Award-winning creative with a track record of campaigns that go viral and build brand equity that lasts." },
  { initials: "NP", name: "Nina Patel", role: "Head of Performance", bio: "Media buying and conversion optimization expert who has managed $50M+ in paid media spend." },
];

const checkList = [
  "Data-driven strategies built on rigorous market research and real-time analytics that adapt to your market.",
  "Full-funnel expertise from awareness through conversion and retention — we own the entire growth journey.",
  "Transparent reporting with custom dashboards giving you real-time visibility into every campaign performance metric.",
  "A dedicated team that treats your business like their own, with senior talent leading every account.",
];

export default function AboutPage() {
  return (
    <>
      {/* Page Hero */}
      <div className="page-hero-accent relative overflow-hidden bg-[#f7f5f0] px-10 pb-24 pt-40">
        <div className="relative mx-auto max-w-[1200px]">
          <div className="mb-6 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            Our Story
          </div>
          <h1 className="max-w-[800px] font-syne text-[clamp(2.5rem,5vw,4.5rem)] font-extrabold leading-[1.05] tracking-[-1.5px] text-[#1a1a1a]">
            Turning Bold Ideas Into<br />Market-Moving Results
          </h1>
          <p className="mt-6 max-w-[520px] text-[1.05rem] leading-[1.75] text-[#666]">
            Founded in 2018, Pixantra has grown from a two-person startup to a 40+ person agency trusted by industry-leading brands worldwide.
          </p>
        </div>
      </div>

      {/* About Grid */}
      <div className="mx-auto max-w-[1200px] px-10 py-24">
        <div className="grid grid-cols-1 items-center gap-20 md:grid-cols-2">
          {/* Image Stack */}
          <div className="relative h-[500px]">
            <div className="absolute bottom-0 left-0 flex h-[380px] w-4/5 items-center justify-center overflow-hidden rounded-[32px] bg-gradient-to-br from-[#0f78ed] to-[#0a5db8]">
              <div className="text-center text-white/80">
                <div className="mb-2 text-[4rem]">🏆</div>
                <div className="text-[0.8rem] uppercase tracking-[2px] opacity-70">Agency of the Year</div>
              </div>
            </div>
            <div className="absolute right-0 top-0 flex h-[240px] w-[55%] items-center justify-center rounded-[22px] border-[3px] border-[#f7f5f0] bg-[#111]">
              <div className="text-center text-white/50">
                <div className="mb-2 text-[2.5rem]">✦</div>
                <div className="font-syne text-[0.72rem] uppercase tracking-[2px]">Since 2018</div>
              </div>
            </div>
            <div className="absolute -right-5 bottom-10 rounded-[14px] border border-[#e8e4dc] bg-white px-6 py-5 shadow-[0_20px_40px_rgba(0,0,0,0.08)]">
              <div className="font-syne text-[1.8rem] font-extrabold leading-none text-[#0f78ed]">200+</div>
              <div className="mt-1 text-[0.78rem] font-medium text-[#666]">Brands Grown</div>
            </div>
          </div>

          {/* Content */}
          <div>
            <div className="mb-5 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
              <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
              Who We Are
            </div>
            <h2 className="mb-6 font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
              We Don't Just Run Campaigns — We Build Growth Engines
            </h2>
            <p className="text-[1rem] leading-[1.75] text-[#666]">
              Pixantra is a collective of strategists, creatives, and data scientists united by one goal: making your brand impossible to ignore. We combine cutting-edge technology with human creativity to deliver marketing that truly works.
            </p>

            <div className="mt-8 flex flex-col gap-4">
              {checkList.map((item, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div className="mt-0.5 flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full border-[1.5px] border-[#0f78ed] bg-[#0f78ed]/10">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#0f78ed" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>
                  <div className="text-[0.92rem] leading-[1.7] text-[#666]">{item}</div>
                </div>
              ))}
            </div>

            <div className="mt-10">
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 rounded-full bg-[#0f78ed] px-8 py-4 text-[0.95rem] font-bold text-white no-underline transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#3d96f5] hover:shadow-[0_15px_30px_rgba(15,120,237,0.3)]"
              >
                Work With Us
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="bg-[#111]">
        <div className="mx-auto max-w-[1200px] px-10 py-16">
          <div
            className="grid grid-cols-1 overflow-hidden rounded-[22px] border border-[#2a2a2a] md:grid-cols-4"
            style={{ gap: "1px", background: "#2a2a2a" }}
          >
            {[["200+", "+", "Clients Served"], ["7", "yr", "In Business"], ["40+", "+", "Team Members"], ["18+", "+", "Industry Awards"]].map(([n, u, l], i) => (
              <div key={i} className="bg-[#1a1a1a] px-10 py-12 text-center">
                <div className="font-syne text-[3rem] font-extrabold leading-none text-white">
                  {n}<span className="text-[2rem] text-[#0f78ed]">{u}</span>
                </div>
                <div className="mt-3 text-[0.82rem] uppercase tracking-[1.5px] text-[#888]">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Team */}
      <div className="mx-auto max-w-[1200px] px-10 py-24">
        <div className="mb-16 text-center">
          <div className="mb-5 inline-flex items-center justify-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            The Crew
          </div>
          <h2 className="mx-auto max-w-[700px] font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
            Meet the Minds Behind<br />Your Growth
          </h2>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-4">
          {team.map((m, i) => (
            <div key={i} className="team-card rounded-[22px] border border-[#e8e4dc] bg-white p-8 text-center" style={{ cursor: "none" }}>
              <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#0f78ed] to-[#0a5db8] font-syne text-[1.2rem] font-extrabold text-white">
                {m.initials}
              </div>
              <div className="mb-1.5 font-syne text-[1rem] font-bold text-[#1a1a1a]">{m.name}</div>
              <div className="mb-3 text-[0.82rem] font-semibold uppercase tracking-[0.5px] text-[#0f78ed]">{m.role}</div>
              <div className="text-[0.83rem] leading-[1.6] text-[#666]">{m.bio}</div>
            </div>
          ))}
        </div>
      </div>

      <CTASection
        badge="Join Our Clients"
        title="Ready to Work With<br/>the Best?"
        sub="Let's have a conversation about your goals and how Pixantra can help you achieve them faster."
        primaryLabel="Get Started Today"
        primaryHref="/contact"
        secondaryLabel="See Pricing"
        secondaryHref="/pricing"
      />
      <Footer />
    </>
  );
}
