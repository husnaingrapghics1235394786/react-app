"use client";

import { useState } from "react";
import Link from "next/link";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const plans = [
  {
    name: "Starter",
    monthly: 1499,
    yearly: 1199,
    desc: "Perfect for growing businesses ready to invest in professional digital marketing and build a strong foundation.",
    features: ["SEO Audit & Strategy", "4 Blog Posts / Month", "Social Media (2 platforms)", "Monthly Reporting", "Email Support"],
    featured: false,
    cta: "Get Started",
  },
  {
    name: "Growth",
    monthly: 3499,
    yearly: 2799,
    desc: "For ambitious brands serious about scaling their digital presence and dominating their market category.",
    features: ["Full SEO Management", "10 Content Pieces / Month", "Paid Ads Management (up to $20K)", "All Social Platforms", "Weekly Reporting + Dashboard", "Dedicated Account Manager"],
    featured: true,
    cta: "Get Started",
  },
  {
    name: "Enterprise",
    monthly: null,
    yearly: null,
    desc: "Tailored solutions for established brands with complex needs, multiple markets, or enterprise-scale operations.",
    features: ["Full-Service Marketing Team", "Unlimited Content Production", "Unlimited Ad Spend Management", "Multi-Market Strategy", "C-Suite Strategy Sessions", "24/7 Priority Support"],
    featured: false,
    cta: "Contact Sales",
  },
];

const comparison = [
  ["SEO Services", "Basic", "Full", "Advanced"],
  ["Paid Advertising", "—", "Up to $20K", "Unlimited"],
  ["Content / Month", "4 pieces", "10 pieces", "Unlimited"],
  ["Social Platforms", "2", "All", "All + Custom"],
  ["Dedicated AM", "—", "✓", "✓"],
  ["Custom Dashboard", "—", "✓", "✓"],
  ["Strategy Sessions", "Monthly", "Weekly", "On-demand"],
];

export default function PricingPage() {
  const [yearly, setYearly] = useState(false);

  return (
    <>
      {/* Hero */}
      <div className="page-hero-accent relative overflow-hidden bg-[#f7f5f0] px-10 pb-24 pt-40">
        <div className="relative mx-auto max-w-[1200px]">
          <div className="mb-6 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            Pricing
          </div>
          <h1 className="max-w-[800px] font-syne text-[clamp(2.5rem,5vw,4.5rem)] font-extrabold leading-[1.05] tracking-[-1.5px] text-[#1a1a1a]">
            Simple, Transparent<br />Pricing for Every Stage
          </h1>
          <p className="mt-6 max-w-[520px] text-[1.05rem] leading-[1.75] text-[#666]">
            No hidden fees, no long-term contracts you can't exit. Just straightforward pricing tied to real results.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-[1200px] px-10 py-16">
        {/* Toggle */}
        <div className="mb-16 flex items-center justify-center gap-4">
          <span className={`text-[0.9rem] font-semibold ${!yearly ? "text-[#1a1a1a]" : "text-[#666]"}`}>Monthly</span>
          <button
            className="toggle-track relative h-7 w-[52px] rounded-full bg-[#0f78ed]"
            onClick={() => setYearly(!yearly)}
            style={{ cursor: "none" }}
          >
            <div
              className="absolute top-[3px] h-[22px] w-[22px] rounded-full bg-white shadow-md transition-transform duration-300"
              style={{ left: "3px", transform: yearly ? "translateX(24px)" : "translateX(0)" }}
            />
          </button>
          <span className={`text-[0.9rem] font-semibold ${yearly ? "text-[#1a1a1a]" : "text-[#666]"}`}>Yearly</span>
          <span className="rounded-full border border-[#0f78ed]/20 bg-[#0f78ed]/10 px-2.5 py-1 text-[0.72rem] font-bold tracking-[0.5px] text-[#0f78ed]">
            Save 20%
          </span>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {plans.map((p, i) => (
            <div
              key={i}
              className={`relative rounded-[32px] p-12 transition-all duration-300 ${
                p.featured
                  ? "pricing-featured border border-[#0f78ed] bg-[#0a0a0a]"
                  : "border border-[#e8e4dc] bg-white"
              }`}
            >
              {p.featured && (
                <div className="absolute left-1/2 top-[-14px] -translate-x-1/2 rounded-full bg-[#0f78ed] px-5 py-1.5 text-[0.72rem] font-bold uppercase tracking-[1.5px] text-white whitespace-nowrap">
                  Most Popular
                </div>
              )}
              <div className="mb-4 text-[0.78rem] font-bold uppercase tracking-[2px] text-[#0f78ed]">{p.name}</div>
              <div className={`mb-2 font-syne text-[3.5rem] font-extrabold leading-none ${p.featured ? "text-white" : "text-[#1a1a1a]"}`}>
                {p.monthly ? (
                  <>
                    <sup className="text-[1.5rem] align-top mt-3 inline-block">$</sup>
                    {(yearly ? p.yearly! : p.monthly).toLocaleString()}
                    <sub className={`text-[1rem] font-normal ${p.featured ? "text-[#888]" : "text-[#666]"}`}>/mo</sub>
                  </>
                ) : (
                  <span className="text-[2rem]">Custom</span>
                )}
              </div>
              <div className={`mb-9 border-b pb-9 text-[0.88rem] leading-[1.6] ${p.featured ? "border-[#2a2a2a] text-[#888]" : "border-[#e8e4dc] text-[#666]"}`}>
                {p.desc}
              </div>
              <div className="mb-10 flex flex-col gap-3.5">
                {p.features.map((f) => (
                  <div key={f} className="flex items-center gap-3">
                    <div className={`flex h-5 w-5 items-center justify-center rounded-full ${p.featured ? "bg-[#0f78ed]/20" : "bg-[#0f78ed]/10"}`}>
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#0f78ed" strokeWidth="3">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                    </div>
                    <span className={`text-[0.88rem] ${p.featured ? "text-white/80" : "text-[#1a1a1a]"}`}>{f}</span>
                  </div>
                ))}
              </div>
              <Link
                href="/contact"
                className={`block rounded-full py-4 text-center text-[0.9rem] font-bold no-underline tracking-[0.3px] transition-all duration-200 ${
                  p.featured
                    ? "bg-[#0f78ed] text-white hover:bg-[#3d96f5] hover:scale-[1.02]"
                    : "border border-[#e8e4dc] bg-transparent text-[#1a1a1a] hover:border-[#0f78ed] hover:text-[#0f78ed]"
                }`}
              >
                {p.cta}
              </Link>
            </div>
          ))}
        </div>

        {/* Comparison table */}
        <div className="mt-20 overflow-hidden rounded-[32px] border border-[#e8e4dc] bg-white">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="border-b border-[#e8e4dc] bg-[#f7f5f0] px-7 py-5 text-left font-syne text-[0.85rem] font-bold text-[#1a1a1a]">Features</th>
                {["Starter", "Growth", "Enterprise"].map((h) => (
                  <th key={h} className="border-b border-[#e8e4dc] bg-[#f7f5f0] px-7 py-5 text-center font-syne text-[0.85rem] font-bold text-[#0f78ed]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparison.map(([feat, s, g, e], i) => (
                <tr key={i} className="hover:bg-[#f7f5f0]">
                  <td className="border-b border-[#e8e4dc] px-7 py-4 text-[0.88rem] text-[#666]">{feat}</td>
                  {[s, g, e].map((v, j) => (
                    <td key={j} className="border-b border-[#e8e4dc] px-7 py-4 text-center text-[0.88rem]">
                      <span className={v === "—" ? "text-[#d4d4d4]" : "font-bold text-[#0f78ed]"}>{v}</span>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <CTASection
        badge="Not Sure?"
        title="Let's Find the Right<br/>Plan for You"
        sub="Book a free consultation and we'll recommend the exact services and investment level that makes sense for your goals."
        primaryLabel="Book Free Consultation"
        primaryHref="/contact"
      />
      <Footer />
    </>
  );
}
