"use client";

import { useState } from "react";
import Link from "next/link";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const allCases = [
  { cat: "seo", icon: "🚀", bg: "linear-gradient(135deg,#0f78ed15,#0f78ed30)", label: "SEO", client: "Earny Finance", title: "340% organic growth in 8 months", desc: "Comprehensive SEO strategy transforming Earny's organic presence." },
  { cat: "paid", icon: "🎯", bg: "linear-gradient(135deg,#111,#1e1e1e)", label: "Paid Media", client: "Scomish Retail", title: "5.2x ROAS on paid social", desc: "Precision-targeted campaigns slashing CAC while scaling revenue." },
  { cat: "content", icon: "📚", bg: "linear-gradient(135deg,#0a2a0a,#0a1a0a)", label: "Content", client: "EduLearn Platform", title: "280% increase in lead quality", desc: "Content-driven inbound strategy attracting high-intent decision makers." },
  { cat: "brand", icon: "✨", bg: "linear-gradient(135deg,#1a0a2a,#0f0620)", label: "Branding", client: "Fictional Studio", title: "Complete brand repositioning", desc: "New identity driving 89% increase in premium client acquisition." },
  { cat: "seo", icon: "🌐", bg: "linear-gradient(135deg,#0a1520,#091020)", label: "SEO", client: "TechFlow SaaS", title: "From page 8 to #1 in 6 months", desc: "Technical SEO overhaul and content expansion dominating competitive terms." },
  { cat: "paid", icon: "💰", bg: "linear-gradient(135deg,#1a0a0a,#200a0a)", label: "Paid Media", client: "Nexus Commerce", title: "$2M revenue in 90 days via Google", desc: "Shopping campaigns and search ads built for scale from day one." },
];

const filters = [
  { key: "all", label: "All Projects" },
  { key: "seo", label: "SEO" },
  { key: "paid", label: "Paid Media" },
  { key: "content", label: "Content" },
  { key: "brand", label: "Branding" },
];

export default function CaseStudyPage() {
  const [active, setActive] = useState("all");
  const filtered = active === "all" ? allCases : allCases.filter((c) => c.cat === active);

  return (
    <>
      {/* Dark Hero */}
      <div className="bg-[#111] px-10 pb-16 pt-40">
        <div className="mx-auto max-w-[1200px]">
          <div className="mb-6 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            Our Work
          </div>
          <h1 className="mb-8 max-w-[900px] font-syne text-[clamp(3rem,6vw,5rem)] font-extrabold leading-[1.05] tracking-[-2px] text-white">
            Real Results for<br />Real Businesses
          </h1>
          <p className="mb-10 max-w-[520px] text-[1.05rem] leading-[1.75] text-[#888]">
            Explore how we've transformed brands across industries with data-driven marketing that delivers measurable impact.
          </p>

          {/* Filters */}
          <div className="flex flex-wrap gap-3">
            {filters.map((f) => (
              <button
                key={f.key}
                onClick={() => setActive(f.key)}
                className={`rounded-full border px-5 py-2 text-[0.82rem] font-semibold tracking-[0.5px] transition-all duration-200 ${
                  active === f.key
                    ? "border-[#0f78ed] bg-[#0f78ed] text-white"
                    : "border-[#2a2a2a] bg-white/5 text-white/50 hover:border-[#0f78ed] hover:bg-[#0f78ed] hover:text-white"
                }`}
                style={{ cursor: "none" }}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cases */}
      <div className="bg-[#111]">
        <div className="mx-auto max-w-[1200px] px-10 pb-24 pt-16">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {filtered.map((c, i) => (
              <Link
                key={i}
                href="#"
                className="case-card block overflow-hidden rounded-[22px] border border-[#2a2a2a] bg-[#1a1a1a] no-underline"
              >
                <div className="relative h-[220px] overflow-hidden">
                  <div
                    className="case-img-inner flex h-full w-full items-center justify-center"
                    style={{ background: c.bg }}
                  >
                    <span className="text-[2.5rem]">{c.icon}</span>
                  </div>
                  <div className="absolute left-5 top-5 rounded-full bg-[#0f78ed] px-3.5 py-1.5 text-[0.72rem] font-bold uppercase tracking-[1.5px] text-white">
                    {c.label}
                  </div>
                </div>
                <div className="p-8">
                  <div className="mb-2.5 text-[0.78rem] font-semibold uppercase tracking-[1.5px] text-[#0f78ed]">{c.client}</div>
                  <div className="mb-3 font-syne text-[1.3rem] font-bold leading-[1.3] text-white">{c.title}</div>
                  <div className="mb-6 text-[0.88rem] leading-[1.65] text-[#888]">{c.desc}</div>
                  <div className="inline-flex items-center gap-2 text-[0.82rem] font-semibold uppercase tracking-[0.5px] text-[#0f78ed]">
                    Full Case Study
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M7 17L17 7M7 7h10v10" />
                    </svg>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <CTASection
        badge="Be Our Next Case Study"
        title="Your Success Story<br/>Starts Here"
        sub="Every case study started with a single conversation. Let's have ours today."
        primaryLabel="Start Your Project"
        primaryHref="/contact"
        secondaryLabel="View Pricing"
        secondaryHref="/pricing"
      />
      <Footer />
    </>
  );
}
