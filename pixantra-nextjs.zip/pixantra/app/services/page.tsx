import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const services = [
  {
    num: "01",
    label: "Search Engine Optimization",
    icon: "📈",
    title: "Dominate Search Rankings with Strategic SEO",
    desc: "Our holistic SEO approach combines technical excellence, authoritative content, and strategic link acquisition to build sustainable organic growth that compounds over time.",
    tags: ["Technical SEO", "Keyword Research", "Link Building", "On-Page Optimization", "Local SEO", "E-commerce SEO"],
  },
  {
    num: "02",
    label: "Paid Advertising",
    icon: "🎯",
    title: "Paid Media That Maximizes Every Dollar Spent",
    desc: "Data-driven paid advertising across every major platform. We build, test, and optimize campaigns that consistently deliver above-market ROAS while scaling efficiently.",
    tags: ["Google Ads", "Meta Ads", "LinkedIn Ads", "Creative Testing", "Retargeting", "Shopping Ads"],
  },
  {
    num: "03",
    label: "Content Strategy",
    icon: "✍️",
    title: "Content That Converts Readers Into Revenue",
    desc: "Strategic content creation and distribution that builds authority, attracts qualified traffic, and nurtures prospects through every stage of the buying journey.",
    tags: ["Content Strategy", "Copywriting", "Video Production", "Infographics", "Case Studies", "Thought Leadership"],
  },
  {
    num: "04",
    label: "Social Media",
    icon: "📱",
    title: "Social Media That Builds Real Communities",
    desc: "From strategy to daily execution, we build engaged social communities that amplify your brand message and drive meaningful business results across every platform.",
    tags: ["Community Management", "Content Calendar", "Influencer Marketing", "Social Analytics", "Crisis Management"],
  },
];

export default function ServicesPage() {
  return (
    <>
      {/* Hero */}
      <div className="page-hero-accent relative overflow-hidden bg-[#f7f5f0] px-10 pb-24 pt-40">
        <div className="relative mx-auto max-w-[1200px]">
          <div className="mb-6 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            What We Offer
          </div>
          <h1 className="max-w-[800px] font-syne text-[clamp(2.5rem,5vw,4.5rem)] font-extrabold leading-[1.05] tracking-[-1.5px] text-[#1a1a1a]">
            Full-Spectrum Digital<br />Marketing Services
          </h1>
          <p className="mt-6 max-w-[520px] text-[1.05rem] leading-[1.75] text-[#666]">
            From search to social, paid to organic — every service is built around one thing: growing your business faster.
          </p>
        </div>
      </div>

      {/* Services */}
      <div>
        {services.map((s, i) => (
          <div key={i}>
            <div
              className={`mx-auto grid max-w-[1200px] grid-cols-1 items-center gap-20 px-10 py-20 md:grid-cols-2 ${
                i % 2 === 1 ? "md:[direction:rtl]" : ""
              }`}
            >
              <div className={i % 2 === 1 ? "md:[direction:ltr]" : ""}>
                <div className="relative flex h-[380px] items-center justify-center overflow-hidden rounded-[32px] bg-[#111]">
                  <div className="absolute font-syne text-[5rem] opacity-15">{s.icon}</div>
                  <span className="relative z-10 rounded-full bg-[#0f78ed] px-4 py-2 text-[0.75rem] font-bold uppercase tracking-[1.5px] text-white">
                    {s.label}
                  </span>
                </div>
              </div>
              <div className={i % 2 === 1 ? "md:[direction:ltr]" : ""}>
                <div className="mb-4 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
                  <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
                  {s.num}
                </div>
                <h2 className="mb-5 font-syne text-[2.2rem] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
                  {s.title}
                </h2>
                <p className="mb-7 text-[1rem] leading-[1.75] text-[#666]">{s.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {s.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full border border-[#0f78ed]/20 bg-[#0f78ed]/08 px-3.5 py-1.5 text-[0.78rem] font-semibold tracking-[0.3px] text-[#0f78ed]"
                      style={{ background: "rgba(15,120,237,0.08)" }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            {i < services.length - 1 && (
              <div className="mx-auto h-px max-w-[1200px] bg-[#e8e4dc]" />
            )}
          </div>
        ))}
      </div>

      <CTASection
        badge="Let's Talk"
        title="Which Service Does<br/>Your Brand Need?"
        sub="Book a free 30-minute strategy call and we'll recommend the perfect service mix for your goals and budget."
        primaryLabel="Book Free Call"
        primaryHref="/contact"
        secondaryLabel="View Pricing"
        secondaryHref="/pricing"
      />
      <Footer />
    </>
  );
}
