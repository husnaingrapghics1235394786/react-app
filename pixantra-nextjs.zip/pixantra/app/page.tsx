import HeroSection from "@/components/HeroSection";
import MarqueeSection from "@/components/MarqueeSection";
import ServicesGrid from "@/components/ServicesGrid";
import StatsSection from "@/components/StatsSection";
import CaseStudiesPreview from "@/components/CaseStudiesPreview";
import WhySection from "@/components/WhySection";
import Testimonials from "@/components/Testimonials";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <HeroSection />
      <MarqueeSection />
      <ServicesGrid />
      <StatsSection />
      <CaseStudiesPreview />
      <WhySection />
      <Testimonials />
      <CTASection
        badge="Ready to Scale?"
        title="Let's Build Something<br/>Remarkable Together"
        sub="Join 200+ brands who trust Pixantra to drive their growth. Let's start with a free strategy session."
        primaryLabel="Book Free Consultation"
        primaryHref="/contact"
        secondaryLabel="View Our Work"
        secondaryHref="/case-study"
      />
      <Footer />
    </>
  );
}
