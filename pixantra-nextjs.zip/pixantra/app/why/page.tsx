import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const steps = [
  { num: "01", title: "Discovery", desc: "Deep-dive into your business, market, competitors, and audience to build a complete picture of opportunity." },
  { num: "02", title: "Strategy", desc: "Custom roadmap built around your goals, timelines, and budget with clear KPIs and milestones defined." },
  { num: "03", title: "Execute", desc: "Senior-led execution with rigorous quality control, creative excellence, and rapid iteration cycles." },
  { num: "04", title: "Scale", desc: "Continuously optimize and scale what works, eliminating waste and doubling down on highest-impact activities." },
];

const results = [
  { num: "340%", label: "Average Organic Traffic Growth", desc: "Our SEO clients see an average 340% increase in organic traffic within the first 12 months of working with us." },
  { num: "5.2x", label: "Average Paid Media ROAS", desc: "Our paid advertising campaigns consistently deliver above 5x return on ad spend across e-commerce, SaaS, and B2B clients." },
  { num: "97%", label: "Client Retention Rate", desc: "Once brands start working with Pixantra, they don't leave. Our retention rate speaks to the quality and consistency of our results." },
];

const reasons = [
  { icon: "🧠", title: "Senior-Led Teams", desc: "No juniors on your account. Every client works directly with senior strategists and specialists with 7+ years experience." },
  { icon: "📊", title: "Real-Time Reporting", desc: "Custom dashboards with live data so you always know exactly what's happening with your campaigns, 24/7." },
  { icon: "⚡", title: "Agile Execution", desc: "Two-week sprint cycles with continuous optimization mean we adapt fast to market changes and new opportunities." },
  { icon: "🔍", title: "Deep Research", desc: "Every strategy starts with comprehensive market analysis — we never guess, we always validate with data first." },
  { icon: "🌐", title: "Full-Funnel Coverage", desc: "From awareness to retention, we manage the entire marketing funnel so nothing falls through the cracks." },
  { icon: "🤝", title: "True Partnership", desc: "We align our incentives with yours. Performance bonuses, shared KPIs, and genuine investment in your success." },
];

export default function WhyPage() {
  return (
    <>
      {/* Dark Hero */}
      <div className="bg-[#111] px-10 pb-20 pt-40">
        <div className="mx-auto max-w-[1200px]">
          <div className="mb-6 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            Why Pixantra
          </div>
          <h1 className="max-w-[800px] font-syne text-[clamp(2.5rem,5vw,4.5rem)] font-extrabold leading-[1.05] tracking-[-1.5px] text-white">
            The Agency That<br />Actually Delivers
          </h1>
          <p className="mt-6 max-w-[520px] text-[1.05rem] leading-[1.75] text-[#888]">
            We're not here to run campaigns. We're here to build growth systems that compound and create long-term competitive advantages for your brand.
          </p>
        </div>
      </div>

      {/* Process */}
      <div className="mx-auto max-w-[1200px] px-10 py-24">
        <div className="mb-16 text-center">
          <div className="mb-5 inline-flex items-center justify-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            Our Process
          </div>
          <h2 className="mx-auto max-w-[700px] font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
            How We Turn Strategy<br />Into Success
          </h2>
        </div>

        <div className="process-steps-wrapper grid grid-cols-2 gap-8 md:grid-cols-4">
          {steps.map((s, i) => (
            <div key={i} className="relative z-10 text-center">
              <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full border-2 border-[#0f78ed] bg-white font-syne text-[1.3rem] font-extrabold text-[#0f78ed]">
                {s.num}
              </div>
              <div className="mb-2.5 font-syne text-[1rem] font-bold text-[#1a1a1a]">{s.title}</div>
              <div className="text-[0.85rem] leading-[1.6] text-[#666]">{s.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="bg-[#111]">
        <div className="mx-auto max-w-[1200px] px-10 py-24">
          <div className="mb-16 text-center">
            <div className="mb-5 inline-flex items-center justify-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
              <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
              Proven Results
            </div>
            <h2 className="mx-auto max-w-[700px] font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-white">
              Numbers That Define<br />Our Impact
            </h2>
          </div>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {results.map((r, i) => (
              <div key={i} className="result-card relative overflow-hidden rounded-[22px] bg-[#1a1a1a] p-10">
                <div className="mb-3 font-syne text-[3rem] font-extrabold leading-none text-[#0f78ed]">{r.num}</div>
                <div className="mb-2.5 font-syne text-[1rem] font-bold text-white">{r.label}</div>
                <div className="text-[0.85rem] leading-[1.65] text-[#888]">{r.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 6 Reasons */}
      <div className="mx-auto max-w-[1200px] px-10 py-24">
        <div className="mb-16 text-center">
          <div className="mb-5 inline-flex items-center justify-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            What Sets Us Apart
          </div>
          <h2 className="mx-auto max-w-[700px] font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
            6 Reasons Brands<br />Choose Pixantra
          </h2>
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {reasons.map((r, i) => (
            <div key={i} className="why-feat-card flex flex-col rounded-[22px] border border-[#e8e4dc] bg-white p-9" style={{ cursor: "none" }}>
              <div className="mb-5 flex h-[52px] w-[52px] items-center justify-center rounded-[12px] bg-gradient-to-br from-[#0f78ed] to-[#0a5db8] text-[1.3rem] text-white">
                {r.icon}
              </div>
              <div className="mb-3 font-syne text-[1.05rem] font-bold text-[#1a1a1a]">{r.title}</div>
              <div className="text-[0.88rem] leading-[1.65] text-[#666]">{r.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <CTASection
        badge="The Pixantra Difference"
        title="Experience Marketing<br/>Done Right"
        sub="Start with a free strategy session and see firsthand how Pixantra approaches growth differently."
        primaryLabel="Free Strategy Call"
        primaryHref="/contact"
        secondaryLabel="See Our Results"
        secondaryHref="/case-study"
      />
      <Footer />
    </>
  );
}
