import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        blue: {
          DEFAULT: "#0f78ed",
          dark: "#0a5db8",
          light: "#3d96f5",
        },
        dark: {
          DEFAULT: "#111111",
          2: "#1a1a1a",
          3: "#222222",
        },
        offwhite: "#f7f5f0",
        border: {
          DEFAULT: "#e8e4dc",
          dark: "#2a2a2a",
        },
        muted: "#666666",
        gray: {
          DEFAULT: "#888888",
          light: "#d4d4d4",
        },
      },
      fontFamily: {
        syne: ["Syne", "sans-serif"],
        dm: ["DM Sans", "sans-serif"],
      },
      borderRadius: {
        "2xl": "14px",
        "3xl": "22px",
        "4xl": "32px",
      },
      animation: {
        marquee: "marquee 30s linear infinite",
        "scroll-left": "scroll-left 25s linear infinite",
        pulse: "pulse 6s ease-in-out infinite",
        blink: "blink 2s ease-in-out infinite",
      },
      keyframes: {
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        "scroll-left": {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        blink: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.3" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
