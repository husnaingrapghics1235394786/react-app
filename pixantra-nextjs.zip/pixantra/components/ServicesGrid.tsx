import Link from "next/link";

const services = [
  { num: "01", icon: "📈", name: "SEO Marketing", desc: "Dominate search rankings with technical SEO, content strategy, and authoritative link building that drives organic traffic." },
  { num: "02", icon: "🎯", name: "Paid Advertising", desc: "Precision-targeted PPC campaigns across Google, Meta, and LinkedIn that maximize ROI and lower acquisition costs." },
  { num: "03", icon: "✍️", name: "Content Strategy", desc: "Compelling narratives and content ecosystems that engage your audience and convert readers into loyal customers." },
  { num: "04", icon: "📱", name: "Social Media", desc: "Build thriving communities and amplify your brand voice with data-backed social media management and growth strategies." },
  { num: "05", icon: "✉️", name: "Email Marketing", desc: "Personalized email campaigns and automated flows that nurture leads, drive retention, and maximize customer lifetime value." },
  { num: "06", icon: "🎨", name: "Brand Identity", desc: "Strategic brand positioning, visual identity design, and messaging frameworks that make your brand unforgettable." },
];

export default function ServicesGrid() {
  return (
    <div className="mx-auto max-w-[1200px] px-10 py-24">
      <div className="mb-0 flex flex-wrap items-end justify-between gap-6">
        <div>
          <div className="mb-5 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            What We Do
          </div>
          <h2 className="font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
            Service Expertise<br />Built for Growth
          </h2>
        </div>
        <Link
          href="/services"
          className="inline-flex items-center gap-2 rounded-full bg-[#0f78ed] px-8 py-4 text-[0.95rem] font-bold text-white no-underline transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#3d96f5] hover:shadow-[0_15px_30px_rgba(15,120,237,0.3)]"
        >
          All Services
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M5 12h14M12 5l7 7-7 7" />
          </svg>
        </Link>
      </div>

      <div className="mt-15 grid grid-cols-1 gap-6 md:grid-cols-3" style={{ marginTop: "60px" }}>
        {services.map((s) => (
          <div
            key={s.num}
            className="service-card rounded-[22px] border border-[#e8e4dc] bg-white p-10"
            style={{ cursor: "none" }}
          >
            <div className="service-num absolute right-7 top-7 z-10 font-syne text-[0.75rem] font-bold tracking-[1px] text-[#d4d4d4]">
              {s.num}
            </div>
            <div className="service-icon-wrap mb-7 flex h-14 w-14 items-center justify-center rounded-[14px] border border-[#e8e4dc] bg-[#f7f5f0] transition-all duration-300">
              <span className="service-icon text-[1.5rem] transition-colors duration-300">{s.icon}</span>
            </div>
            <div className="service-name mb-3.5 font-syne text-[1.15rem] font-bold text-[#1a1a1a] transition-colors duration-300">{s.name}</div>
            <div className="service-desc mb-7 text-[0.9rem] leading-[1.7] text-[#666] transition-colors duration-300">{s.desc}</div>
            <Link
              href="/services"
              className="service-link inline-flex items-center gap-2 text-[0.85rem] font-semibold text-[#0f78ed] no-underline transition-colors duration-300"
            >
              Learn More
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M7 17L17 7M7 7h10v10" />
              </svg>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
