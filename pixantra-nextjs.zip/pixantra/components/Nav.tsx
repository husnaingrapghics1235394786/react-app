"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/why", label: "Why Us" },
  { href: "/case-study", label: "Case Studies" },
  { href: "/pricing", label: "Pricing" },
  { href: "/contact", label: "Contact" },
];

export default function Nav() {
  const pathname = usePathname();
  const [hidden, setHidden] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  let lastScroll = 0;

  useEffect(() => {
    const onScroll = () => {
      const s = window.scrollY;
      setHidden(s > lastScroll && s > 100);
      lastScroll = s;
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <nav
        className="fixed top-5 left-1/2 z-[1000] w-[calc(100%-40px)] max-w-[1200px]"
        style={{
          transform: `translateX(-50%) translateY(${hidden ? "-120px" : "0"})`,
          transition: "transform 0.4s ease",
        }}
      >
        <div className="flex items-center justify-between rounded-full border border-[#2a2a2a] bg-[#0a0a0a] px-7 py-3.5 shadow-[0_20px_60px_rgba(0,0,0,0.4)] backdrop-blur-xl">
          <Link
            href="/"
            className="font-syne text-[1.3rem] font-extrabold tracking-tight text-white no-underline"
          >
            Pix<span className="text-[#0f78ed]">antra</span>
          </Link>

          <div className="hidden items-center gap-1 md:flex">
            {navLinks.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`rounded-full px-4 py-2 text-[0.85rem] font-medium tracking-[0.2px] transition-all duration-200 no-underline ${
                  pathname === l.href
                    ? "bg-white/10 text-white"
                    : "text-white/60 hover:bg-white/10 hover:text-white"
                }`}
              >
                {l.label}
              </Link>
            ))}
          </div>

          <Link
            href="/contact"
            className="hidden items-center gap-2 rounded-full bg-[#0f78ed] px-5 py-2.5 text-[0.85rem] font-semibold tracking-[0.3px] text-white no-underline transition-all duration-200 hover:scale-[1.02] hover:bg-[#3d96f5] md:flex"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
            Book a Call
          </Link>

          <button
            className="flex flex-col gap-1 bg-transparent border-none md:hidden"
            onClick={() => setMobileOpen(true)}
            style={{ cursor: "none" }}
          >
            <span className="block h-[2px] w-[22px] rounded-sm bg-white" />
            <span className="block h-[2px] w-[22px] rounded-sm bg-white" />
            <span className="block h-[2px] w-[22px] rounded-sm bg-white" />
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[999] flex flex-col gap-4 bg-[#0a0a0a] px-10 pt-24 pb-10">
          <button
            className="absolute top-6 right-8 text-white text-2xl bg-transparent border-none"
            onClick={() => setMobileOpen(false)}
            style={{ cursor: "none" }}
          >
            ✕
          </button>
          {navLinks.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setMobileOpen(false)}
              className={`font-syne text-[2rem] font-extrabold no-underline transition-colors ${
                pathname === l.href ? "text-white" : "text-white/40"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
