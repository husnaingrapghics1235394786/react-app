const testimonials = [
  { initials: "CP", name: "Cristina Perry", role: "Art Director, Copper Agency", text: "Pixantra completely transformed our digital presence. Within 6 months, our organic traffic tripled and we're now ranking for keywords we never dreamed possible." },
  { initials: "MP", name: "Marcus Powell", role: "CEO, Scomish", text: "The paid ads team delivered a 5x ROAS in the first quarter. Their creative testing approach and data-driven optimization is unlike anything we've experienced before." },
  { initials: "SM", name: "Sarah Mitchell", role: "CMO, TechFlow", text: "Their content strategy established us as true thought leaders in our space. The quality of leads coming through organic channels has been exceptional." },
  { initials: "JR", name: "James Rodriguez", role: "Founder, EduLearn", text: "Pixantra's email campaigns drove a 280% increase in repeat purchases. Their segmentation and personalization expertise is world-class." },
];

export default function Testimonials() {
  const doubled = [...testimonials, ...testimonials];
  return (
    <div className="overflow-hidden bg-[#f7f5f0] py-24">
      <div className="mb-16 px-10 text-center">
        <div className="mb-5 inline-flex items-center justify-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
          <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
          Client Love
        </div>
        <h2 className="mx-auto max-w-[700px] font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
          Words From Our Clients
        </h2>
      </div>
      <div className="overflow-hidden">
        <div className="testimonials-track">
          {doubled.map((t, i) => (
            <div
              key={i}
              className="min-w-[380px] flex-shrink-0 rounded-[22px] border border-[#e8e4dc] bg-white p-9"
            >
              <div className="mb-5 text-[1.4rem] font-syne text-[#0f78ed]">❝</div>
              <div className="mb-4 text-[0.78rem] tracking-[2px] text-yellow-400">★★★★★</div>
              <p className="mb-7 text-[0.92rem] leading-[1.75] text-[#666]">{t.text}</p>
              <div className="flex items-center gap-3.5">
                <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#0f78ed] to-[#0a5db8] font-syne text-[0.85rem] font-bold text-white">
                  {t.initials}
                </div>
                <div>
                  <div className="font-syne text-[0.88rem] font-bold text-[#1a1a1a]">{t.name}</div>
                  <div className="mt-0.5 text-[0.78rem] text-[#666]">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
