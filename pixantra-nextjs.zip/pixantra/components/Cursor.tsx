"use client";

import { useEffect } from "react";

export default function Cursor() {
  useEffect(() => {
    const cursor = document.getElementById("cursor");
    const ring = document.getElementById("cursor-ring");
    if (!cursor || !ring) return;

    const onMove = (e: MouseEvent) => {
      cursor.style.left = e.clientX + "px";
      cursor.style.top = e.clientY + "px";
      ring.style.left = e.clientX + "px";
      ring.style.top = e.clientY + "px";
    };

    document.addEventListener("mousemove", onMove);

    const expand = () => {
      cursor.style.transform = "translate(-50%,-50%) scale(1.8)";
      ring.style.width = "56px";
      ring.style.height = "56px";
      cursor.style.background = "#3d96f5";
    };
    const shrink = () => {
      cursor.style.transform = "translate(-50%,-50%) scale(1)";
      ring.style.width = "36px";
      ring.style.height = "36px";
      cursor.style.background = "#0f78ed";
    };

    const targets = document.querySelectorAll(
      "a, button, .service-card, .case-card, .why-feat-card, .team-card, .pricing-card, .case-filter, .toggle-track"
    );
    targets.forEach((el) => {
      el.addEventListener("mouseenter", expand);
      el.addEventListener("mouseleave", shrink);
    });

    return () => {
      document.removeEventListener("mousemove", onMove);
      targets.forEach((el) => {
        el.removeEventListener("mouseenter", expand);
        el.removeEventListener("mouseleave", shrink);
      });
    };
  }, []);

  return (
    <>
      <div id="cursor" />
      <div id="cursor-ring" />
    </>
  );
}
