"use client";

import { useEffect, useRef } from "react";

const stats = [
  { end: 72, unit: "%", label: "SEO Avg Growth" },
  { end: 68, unit: "%", label: "Engagement Rate" },
  { end: 5, unit: "x", label: "Average ROI" },
  { end: 97, unit: "%", label: "Client Retention" },
];

function animateCount(el: HTMLElement, end: number) {
  const startTime = performance.now();
  const step = (now: number) => {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / 2500, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(end * eased).toString();
    if (progress < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

export default function StatsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const animated = useRef(false);

  useEffect(() => {
    if (!ref.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !animated.current) {
          animated.current = true;
          ref.current!.querySelectorAll<HTMLElement>(".count-stat").forEach((el, i) => {
            setTimeout(() => animateCount(el, stats[i].end), i * 150);
          });
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="bg-[#111]">
      <div className="mx-auto max-w-[1200px] px-10 py-24">
        <div className="mb-0 text-center">
          <div className="mb-5 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
            <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
            Our Numbers
          </div>
          <h2 className="mx-auto max-w-[700px] font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-white">
            Yearly Growth That<br />Speaks for Itself
          </h2>
          <p className="mx-auto mt-4 max-w-[500px] text-[1rem] leading-[1.75] text-white/50">
            Every metric reflects our commitment to delivering exceptional results for our clients
          </p>
        </div>

        <div
          ref={ref}
          className="mt-16 grid grid-cols-1 overflow-hidden rounded-[22px] border border-[#2a2a2a] md:grid-cols-4"
          style={{ gap: "1px", background: "#2a2a2a" }}
        >
          {stats.map((s, i) => (
            <div key={i} className="bg-[#1a1a1a] px-10 py-12 text-center">
              <div className="font-syne text-[3rem] font-extrabold leading-none text-white">
                <span className="count-stat">0</span>
                <span className="text-[2rem] text-[#0f78ed]">{s.unit}</span>
              </div>
              <div className="mt-3 text-[0.82rem] uppercase tracking-[1.5px] text-[#888]">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
