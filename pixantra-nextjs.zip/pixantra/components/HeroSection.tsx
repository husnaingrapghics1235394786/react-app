"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";

function animateCount(el: HTMLElement, end: number, duration = 2500) {
  const start = 0;
  const startTime = performance.now();
  const step = (now: number) => {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + (end - start) * eased).toString();
    if (progress < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

export default function HeroSection() {
  const statsRef = useRef<HTMLDivElement>(null);
  const animated = useRef(false);

  useEffect(() => {
    // Trigger counters after short delay
    const timer = setTimeout(() => {
      if (animated.current) return;
      animated.current = true;
      const ids = [
        { id: "stat1", end: 200 },
        { id: "stat2", end: 98 },
        { id: "stat3", end: 450 },
        { id: "stat4", end: 7 },
      ];
      ids.forEach(({ id, end }) => {
        const el = document.getElementById(id);
        if (el) animateCount(el, end);
      });
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative flex min-h-screen items-center overflow-hidden bg-[#0f78ed] pt-24">
      <div className="hero-grid" />
      <div className="hero-blob" />
      <div className="hero-blob2" />

      <div className="relative z-10 mx-auto w-full max-w-[1200px] px-10 pb-20">
        {/* Badge */}
        <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/15 px-4 py-2 backdrop-blur-md">
          <span className="badge-dot h-2 w-2 rounded-full bg-[#00ff88]" />
          <span className="text-[0.8rem] font-medium uppercase tracking-[0.5px] text-white/90">
            Performance-Driven Digital Agency
          </span>
        </div>

        {/* Title */}
        <h1 className="mb-7 max-w-[900px] font-syne text-[clamp(3rem,7vw,6rem)] font-extrabold leading-[1.05] tracking-[-2px] text-white">
          <span className="block overflow-hidden">Marketing That</span>
          <span className="block overflow-hidden">
            <em className="relative not-italic">
              Drives Results
              <span className="absolute bottom-1 left-0 h-1 w-full rounded-sm bg-white/40" />
            </em>
          </span>
          <span className="block overflow-hidden">&amp; Growth</span>
        </h1>

        <p className="mb-12 max-w-[520px] text-[1.1rem] font-normal leading-[1.7] text-white/75">
          We craft data-driven marketing strategies that transform brands, captivate audiences, and deliver measurable ROI for businesses that want to lead.
        </p>

        <div className="flex flex-wrap items-center gap-5">
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 rounded-full bg-white px-8 py-4 font-syne text-[0.95rem] font-bold text-[#0f78ed] no-underline transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_20px_40px_rgba(0,0,0,0.2)]"
          >
            Start Your Project
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </Link>
          <Link
            href="/case-study"
            className="inline-flex items-center gap-2 rounded-full border border-white/40 bg-transparent px-8 py-4 text-[0.95rem] font-semibold text-white no-underline transition-all duration-200 hover:border-white/70 hover:bg-white/10"
          >
            View Case Studies
          </Link>
        </div>

        {/* Stats */}
        <div ref={statsRef} className="mt-16 flex flex-wrap gap-12 border-t border-white/15 pt-12">
          {[
            { id: "stat1", suffix: "+", label: "Happy Clients" },
            { id: "stat2", suffix: "%", label: "Client Satisfaction" },
            { id: "stat3", suffix: "+", label: "Projects Done" },
            { id: "stat4", suffix: "+", label: "Years Experience" },
          ].map((s) => (
            <div key={s.id}>
              <div className="font-syne text-[2.8rem] font-extrabold leading-none text-white">
                <span id={s.id}>0</span>
                {s.suffix}
              </div>
              <div className="mt-1.5 text-[0.82rem] uppercase tracking-[0.8px] text-white/60">
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Wave */}
      <div className="absolute bottom-[-1px] left-0 w-full leading-[0]">
        <svg viewBox="0 0 1440 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" className="block h-20 w-full">
          <path d="M0,40 C360,80 1080,0 1440,40 L1440,80 L0,80 Z" fill="#f7f5f0" />
        </svg>
      </div>
    </section>
  );
}
