import Link from "next/link";

const cases = [
  {
    bg: "linear-gradient(135deg,#0f78ed22,#0f78ed44)",
    icon: "🚀",
    watermark: "EARNY",
    label: "SaaS Growth",
    client: "Earny Finance",
    title: "340% organic traffic growth in 8 months",
    desc: "A comprehensive SEO and content strategy that transformed Earny's digital presence and dominated competitive fintech keywords.",
  },
  {
    bg: "linear-gradient(135deg,#111,#222)",
    icon: "🎯",
    watermark: "SCOMISH",
    label: "E-Commerce",
    client: "Scomish Retail",
    title: "5.2x ROAS on paid social campaigns",
    desc: "Precision-targeted Meta and Google campaigns with dynamic creative testing that slashed CAC while scaling revenue.",
  },
];

export default function CaseStudiesPreview() {
  return (
    <div className="bg-[#111]">
      <div className="mx-auto max-w-[1200px] px-10 pb-24">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
              <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
              Our Work
            </div>
            <h2 className="font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-white">
              Proven Case<br />Studies
            </h2>
          </div>
          <Link
            href="/case-study"
            className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-transparent px-8 py-4 text-[0.95rem] font-semibold text-white/70 no-underline transition-all duration-200 hover:border-white/50 hover:text-white"
          >
            All Case Studies
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </Link>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-2">
          {cases.map((c, i) => (
            <Link
              key={i}
              href="/case-study"
              className="case-card block rounded-[22px] border border-[#2a2a2a] bg-[#1a1a1a] no-underline overflow-hidden"
            >
              <div className="relative h-[260px] overflow-hidden">
                <div
                  className="case-img-inner flex h-full w-full flex-col items-center justify-center gap-3"
                  style={{ background: c.bg }}
                >
                  <span className="text-[3rem]">{c.icon}</span>
                  <span className="font-syne text-[1.5rem] font-extrabold text-white/15">{c.watermark}</span>
                </div>
                <div className="absolute left-5 top-5 rounded-full bg-[#0f78ed] px-3.5 py-1.5 text-[0.72rem] font-bold uppercase tracking-[1.5px] text-white">
                  {c.label}
                </div>
              </div>
              <div className="p-8">
                <div className="mb-2.5 text-[0.78rem] font-semibold uppercase tracking-[1.5px] text-[#0f78ed]">{c.client}</div>
                <div className="mb-3 font-syne text-[1.3rem] font-bold leading-[1.3] text-white">{c.title}</div>
                <div className="mb-6 text-[0.88rem] leading-[1.65] text-[#888]">{c.desc}</div>
                <div className="inline-flex items-center gap-2 text-[0.82rem] font-semibold uppercase tracking-[0.5px] text-[#0f78ed]">
                  Full Case Study
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M7 17L17 7M7 7h10v10" />
                  </svg>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
