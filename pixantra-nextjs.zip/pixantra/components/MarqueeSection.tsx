const items = [
  "SEO Marketing", "Brand Strategy", "Content Creation", "Paid Advertising",
  "Social Media", "Email Marketing", "Analytics & CRO", "Web Design",
];

export default function MarqueeSection() {
  const doubled = [...items, ...items];
  return (
    <div className="overflow-hidden border-b border-[#2a2a2a] border-t border-[#2a2a2a] bg-[#0a0a0a] py-6">
      <div className="marquee-track">
        {doubled.map((item, i) => (
          <div
            key={i}
            className="flex items-center gap-4 whitespace-nowrap px-10 font-syne text-[0.85rem] font-semibold uppercase tracking-[2px] text-white/40"
          >
            <span className="h-1.5 w-1.5 flex-shrink-0 rounded-full bg-[#0f78ed]" />
            {item}
          </div>
        ))}
      </div>
    </div>
  );
}
