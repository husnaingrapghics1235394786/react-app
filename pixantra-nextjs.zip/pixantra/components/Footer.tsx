import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-[#2a2a2a] bg-[#0a0a0a] px-10 pb-10 pt-20">
      <div className="mx-auto max-w-[1200px]">
        <div className="grid grid-cols-1 gap-10 border-b border-[#2a2a2a] pb-16 md:grid-cols-[1.5fr_1fr_1fr_1fr] md:gap-[60px]">
          <div>
            <Link href="/" className="mb-4 block font-syne text-[1.5rem] font-extrabold tracking-tight text-white no-underline">
              Pix<span className="text-[#0f78ed]">antra</span>
            </Link>
            <p className="max-w-[280px] text-[0.88rem] leading-[1.7] text-[#888]">
              Performance-driven digital marketing agency helping ambitious brands achieve extraordinary growth.
            </p>
          </div>
          <div>
            <div className="mb-6 font-syne text-[0.78rem] font-bold uppercase tracking-[2px] text-white">Pages</div>
            <div className="flex flex-col gap-3">
              {[["Home", "/"], ["About Us", "/about"], ["Services", "/services"], ["Why Us", "/why"]].map(([l, h]) => (
                <Link key={h} href={h} className="text-[0.88rem] text-[#888] no-underline transition-colors hover:text-white">{l}</Link>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-6 font-syne text-[0.78rem] font-bold uppercase tracking-[2px] text-white">Work</div>
            <div className="flex flex-col gap-3">
              {[["Case Studies", "/case-study"], ["Pricing", "/pricing"], ["Contact", "/contact"]].map(([l, h]) => (
                <Link key={h} href={h} className="text-[0.88rem] text-[#888] no-underline transition-colors hover:text-white">{l}</Link>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-6 font-syne text-[0.78rem] font-bold uppercase tracking-[2px] text-white">Contact</div>
            <div className="flex flex-col gap-3">
              <a href="mailto:hello@pixantra.com" className="text-[0.88rem] text-[#888] no-underline transition-colors hover:text-white">hello@pixantra.com</a>
              <a href="tel:+15552345678" className="text-[0.88rem] text-[#888] no-underline transition-colors hover:text-white">+1 (555) 234-5678</a>
              <span className="text-[0.88rem] text-[#888]">New York, NY</span>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between pt-10">
          <div className="text-[0.82rem] text-[#888]">
            © 2025 <span className="text-[#0f78ed]">Pixantra</span>. All rights reserved.
          </div>
          <div className="flex gap-3">
            {["X", "in", "ig", "yt"].map((s) => (
              <a key={s} href="#" className="flex h-[38px] w-[38px] items-center justify-center rounded-full border border-[#2a2a2a] text-[0.82rem] font-bold text-[#888] no-underline transition-all hover:border-[#0f78ed] hover:text-[#0f78ed]">{s}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
