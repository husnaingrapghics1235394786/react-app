"use client";

import { useEffect, useRef } from "react";

const features = [
  {
    icon: "🔬",
    title: "Research-First Approach",
    desc: "We dive deep into market data, competitor analysis, and audience insights before crafting any strategy — ensuring every decision is backed by evidence.",
  },
  {
    icon: "💡",
    title: "Creative Intelligence",
    desc: "Blending analytical rigor with creative excellence to develop campaigns that stand out in crowded markets and resonate deeply with target audiences.",
  },
  {
    icon: "🤝",
    title: "Transparent Partnership",
    desc: "Real-time dashboards, weekly reports, and dedicated account managers keep you informed and in control of every aspect of your campaigns.",
  },
];

const metrics = [
  { label: "SEO Rankings", width: "88%", val: "88%" },
  { label: "Paid Media ROAS", width: "76%", val: "5.2x" },
  { label: "Client Satisfaction", width: "97%", val: "97%" },
  { label: "Retention Rate", width: "92%", val: "92%" },
];

export default function WhySection() {
  const barsRef = useRef<HTMLDivElement>(null);
  const animated = useRef(false);

  useEffect(() => {
    if (!barsRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !animated.current) {
          animated.current = true;
          barsRef.current!.querySelectorAll<HTMLElement>(".metric-fill").forEach((bar) => {
            const w = bar.dataset.width || "0%";
            bar.style.width = w;
          });
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(barsRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="mx-auto max-w-[1200px] px-10 py-24">
      <div className="mb-5 inline-flex items-center gap-2 text-[0.78rem] font-semibold uppercase tracking-[2px] text-[#0f78ed]">
        <span className="h-0.5 w-5 rounded-sm bg-[#0f78ed]" />
        Why Pixantra
      </div>
      <h2 className="mb-0 font-syne text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-[-1px] text-[#1a1a1a]">
        We Are Your Best<br />Marketing Partner
      </h2>

      <div className="mt-16 grid grid-cols-1 gap-16 md:grid-cols-2">
        {/* Features */}
        <div className="flex flex-col gap-7">
          {features.map((f, i) => (
            <div
              key={i}
              className="why-feat-card flex gap-5 rounded-[14px] border border-[#e8e4dc] bg-white p-7"
              style={{ cursor: "none" }}
            >
              <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-[12px] bg-gradient-to-br from-[#0f78ed] to-[#0a5db8] text-[1.3rem] text-white">
                {f.icon}
              </div>
              <div>
                <div className="mb-2 font-syne text-[1rem] font-bold text-[#1a1a1a]">{f.title}</div>
                <div className="text-[0.88rem] leading-[1.65] text-[#666]">{f.desc}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Dashboard visual */}
        <div
          ref={barsRef}
          className="relative overflow-hidden rounded-[32px] bg-[#111] p-12"
        >
          <div className="why-visual-bg absolute inset-0" />
          <div className="relative z-10">
            <div className="mb-8 text-[0.75rem] font-bold uppercase tracking-[2px] text-[#0f78ed]">
              Performance Dashboard
            </div>
            {metrics.map((m, i) => (
              <div key={i} className="mb-8 last:mb-0">
                <div className="mb-2.5 text-[0.78rem] font-semibold uppercase tracking-[1.5px] text-[#888]">{m.label}</div>
                <div className="h-1.5 overflow-hidden rounded-sm bg-white/10">
                  <div
                    className="metric-fill h-full w-0 rounded-sm"
                    data-width={m.width}
                    style={{ transition: "width 1.5s ease" }}
                  />
                </div>
                <div className="mt-2 font-syne text-[1.6rem] font-extrabold text-white">{m.val}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
