import Link from "next/link";

interface CTAProps {
  badge: string;
  title: string;
  sub: string;
  primaryLabel: string;
  primaryHref: string;
  secondaryLabel?: string;
  secondaryHref?: string;
}

export default function CTASection({
  badge,
  title,
  sub,
  primaryLabel,
  primaryHref,
  secondaryLabel,
  secondaryHref,
}: CTAProps) {
  return (
    <div className="cta-glow relative overflow-hidden bg-[#0a0a0a] px-10 py-24 text-center">
      <div className="relative z-10">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#0f78ed]/30 bg-[#0f78ed]/15 px-4 py-2">
          <span className="text-[0.78rem] font-semibold uppercase tracking-[1.5px] text-[#0f78ed]">{badge}</span>
        </div>
        <h2
          className="mb-6 font-syne text-[clamp(2.5rem,5vw,4rem)] font-extrabold leading-[1.1] tracking-[-1.5px] text-white"
          dangerouslySetInnerHTML={{ __html: title }}
        />
        <p className="mx-auto mb-12 max-w-[480px] text-[1.05rem] leading-[1.7] text-[#888]">{sub}</p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link
            href={primaryHref}
            className="inline-flex items-center gap-2 rounded-full bg-white px-8 py-4 text-[0.95rem] font-bold text-[#0f78ed] no-underline transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_20px_40px_rgba(0,0,0,0.2)]"
          >
            {primaryLabel}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </Link>
          {secondaryLabel && secondaryHref && (
            <Link
              href={secondaryHref}
              className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-transparent px-8 py-4 text-[0.95rem] font-semibold text-white/70 no-underline transition-all duration-200 hover:border-white/50 hover:text-white"
            >
              {secondaryLabel}
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
